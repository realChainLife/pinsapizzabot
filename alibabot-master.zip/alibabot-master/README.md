A Telegram bot, for the use case of a local pizza shop.
